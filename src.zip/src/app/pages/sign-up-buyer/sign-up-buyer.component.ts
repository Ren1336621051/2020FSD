import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-buyer',
  templateUrl: './sign-up-buyer.component.html',
  styleUrls: ['./sign-up-buyer.component.css']
})
export class SignUpBuyerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
