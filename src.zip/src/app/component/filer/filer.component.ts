import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filer',
  templateUrl: './filer.component.html',
  styleUrls: ['./filer.component.css']
})
export class FilerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
